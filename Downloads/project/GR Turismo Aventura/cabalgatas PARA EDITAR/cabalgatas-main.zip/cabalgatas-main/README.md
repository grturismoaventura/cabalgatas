# GR Turismo Aventura

Website oficial de GR Turismo Aventura - Cabalgatas y aventuras en la naturaleza.

## Tecnologías

- Next.js 13.5.1
- React
- Tailwind CSS
- TypeScript

## Desarrollo

```bash
npm install
npm run dev
```

## Despliegue

Este proyecto está configurado para desplegarse en Vercel.
